"""
Module untuk melatih model menggunakan TFX Trainer.
File ini akan digunakan oleh komponen Trainer di pipeline.
"""

import tensorflow as tf
import tensorflow_transform as tft
from tensorflow_transform.tf_metadata import schema_utils

# Import dari transform.py
from modules.transform import (
    NUMERICAL_FEATURES,
    CATEGORICAL_FEATURES,
    LABEL_KEY,
    _transformed_name,
)


def _get_binary_classification_model(input_features):
    """
    Membangun arsitektur model klasifikasi biner sederhana.
    
    Args:
        input_features: List dari Keras Input layers.
    
    Returns:
        Compiled Keras model.
    """
    concat = tf.keras.layers.concatenate(input_features)
    deep = tf.keras.layers.Dense(128, activation='relu')(concat)
    deep = tf.keras.layers.Dropout(0.3)(deep)
    deep = tf.keras.layers.Dense(64, activation='relu')(deep)
    deep = tf.keras.layers.Dropout(0.2)(deep)
    output = tf.keras.layers.Dense(1, activation='sigmoid')(deep)

    model = tf.keras.Model(inputs=input_features, outputs=output)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(learning_rate=0.001),
        loss=tf.keras.losses.BinaryCrossentropy(),
        metrics=[tf.keras.metrics.BinaryAccuracy(), tf.keras.metrics.AUC()]
    )
    return model


def _input_fn(file_pattern, tf_transform_output, batch_size=32):
    """
    Membuat input function untuk training dan evaluation.
    
    Args:
        file_pattern: Pattern untuk file TFRecord.
        tf_transform_output: Output dari Transform component.
        batch_size: Ukuran batch.
    
    Returns:
        tf.data.Dataset.
    """
    transformed_feature_spec = (
        tf_transform_output.transformed_feature_spec().copy()
    )

    dataset = tf.data.experimental.make_batched_features_dataset(
        file_pattern=file_pattern,
        batch_size=batch_size,
        features=transformed_feature_spec,
        label_key=_transformed_name(LABEL_KEY),
        reader=tf.data.TFRecordDataset,
    )
    return dataset


def run_fn(fn_args):
    """
    Fungsi utama yang akan dipanggil oleh TFX Trainer.
    
    Args:
        fn_args: Argument dari Trainer component berisi path data, schema, dll.
    """
    tf_transform_output = tft.TFTransformOutput(fn_args.transform_output)

    train_dataset = _input_fn(fn_args.train_files, tf_transform_output, 32)
    eval_dataset = _input_fn(fn_args.eval_files, tf_transform_output, 32)

    # Bangun input layer berdasarkan schema
    input_features = []
    for key in NUMERICAL_FEATURES + CATEGORICAL_FEATURES:
        input_features.append(
            tf.keras.layers.Input(
                name=_transformed_name(key), shape=(), dtype=tf.float32
            )
        )

    model = _get_binary_classification_model(input_features)

    model.fit(
        train_dataset,
        steps_per_epoch=fn_args.train_steps,
        validation_data=eval_dataset,
        validation_steps=fn_args.eval_steps,
        epochs=10,
        verbose=1,
    )

    # Simpan model beserta transform graph
    model.save(
        fn_args.serving_model_dir,
        save_format='tf',
        signatures={
            'serving_default': tf.function(
                input_signature=[
                    tf.TensorSpec(shape=[None], dtype=tf.float32, name=_transformed_name(f))
                    for f in NUMERICAL_FEATURES + CATEGORICAL_FEATURES
                ]
            )
        }
    )