"""
Module untuk preprocessing data menggunakan TFX Transform.
File ini akan digunakan oleh komponen Transform di pipeline.
"""

import tensorflow as tf
import tensorflow_transform as tft


# Definisikan nama fitur (sesuaikan dengan dataset Anda)
NUMERICAL_FEATURES = ['feature_1', 'feature_2', 'feature_3']
CATEGORICAL_FEATURES = ['category_feature']
LABEL_KEY = 'target'  # Ganti dengan nama kolom target Anda


def _transformed_name(key):
    """Mengembalikan nama fitur yang sudah ditransformasi."""
    return f'{key}_xf'


def preprocessing_fn(inputs):
    """
    Fungsi preprocessing yang akan dipanggil oleh TFX Transform.
    
    Args:
        inputs: Dictionary dari nama fitur ke Tensor.
    
    Returns:
        Dictionary dari nama fitur hasil transformasi ke Tensor.
    """
    outputs = inputs.copy()

    # Normalisasi fitur numerik (z-score)
    for feature in NUMERICAL_FEATURES:
        outputs[_transformed_name(feature)] = tft.scale_to_z_score(
            tf.cast(inputs[feature], tf.float32)
        )

    # Encode fitur kategorikal menjadi integer
    for feature in CATEGORICAL_FEATURES:
        outputs[_transformed_name(feature)] = tft.compute_and_apply_vocabulary(
            inputs[feature], vocab_filename=feature
        )

    # Pastikan label bertipe float
    outputs[_transformed_name(LABEL_KEY)] = tf.cast(inputs[LABEL_KEY], tf.float32)

    return outputs